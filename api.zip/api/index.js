const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

const Daraja = require('@saverious/daraja');

const app = express();
dotenv.config();
app.use(cors({
    origin: "*"
}));
app.use(express.json());

app.post('/mpesa', (req, res) => {
    async function payViaMpesa() {
        try{
            const daraja = new Daraja({
                consumer_key : process.env.CONSUMER_KEY,
                consumer_secret : process.env.CONSUMER_SECRET,
                environment : 'production' 
            });
            
            const response = await daraja.stkPush({
                sender_phone : req.body.number,
                payBillOrTillNumber : process.env.SHORT_CODE,
                passkey: process.env.PASS_KEY,
                amount : req.body.amount,
                callback_url : "https://powerkingtips.com/tips"
            });
            res.status(200).json(response)
        }catch(error){
            res.status(500).json(error.message);
        }
    }
    payViaMpesa();
})
app.listen();